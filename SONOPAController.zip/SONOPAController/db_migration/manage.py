#!/usr/bin/env python
from migrate.versioning.shell import main

if __name__ == '__main__':
    main(six='<module 'six' from '/usr/lib/python2.7/dist-packages/six.pyc'>')
