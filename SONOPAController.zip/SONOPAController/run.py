#!flask/bin/python
__author__ = 'hasier'

from app import app

if __name__ == '__main__':
    app.config['UPDATE-SOCIAL-NETWORK'] = False
    app.config['FAKE-SENSORS'] = True

    app.run(debug = True)